--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE pawsco_dev;
--
-- Name: pawsco_dev; Type: DATABASE; Schema: -; Owner: pawsco_user
--

CREATE DATABASE pawsco_dev WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE pawsco_dev OWNER TO pawsco_user;

\unrestrict (null)
\connect pawsco_dev
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: booking_addons; Type: TABLE; Schema: public; Owner: pawsco_user
--

CREATE TABLE public.booking_addons (
    id integer NOT NULL,
    booking_id integer NOT NULL,
    addon_id integer,
    price_at_purchase numeric(10,2),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.booking_addons OWNER TO pawsco_user;

--
-- Name: booking_addons_id_seq; Type: SEQUENCE; Schema: public; Owner: pawsco_user
--

CREATE SEQUENCE public.booking_addons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.booking_addons_id_seq OWNER TO pawsco_user;

--
-- Name: booking_addons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawsco_user
--

ALTER SEQUENCE public.booking_addons_id_seq OWNED BY public.booking_addons.id;


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: pawsco_user
--

CREATE TABLE public.bookings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    pet_id integer NOT NULL,
    service_id integer NOT NULL,
    booking_date date NOT NULL,
    booking_time time without time zone,
    special_notes text,
    subtotal numeric(10,2),
    tax numeric(10,2),
    total numeric(10,2),
    status character varying(50) DEFAULT 'pending'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.bookings OWNER TO pawsco_user;

--
-- Name: bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: pawsco_user
--

CREATE SEQUENCE public.bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bookings_id_seq OWNER TO pawsco_user;

--
-- Name: bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawsco_user
--

ALTER SEQUENCE public.bookings_id_seq OWNED BY public.bookings.id;


--
-- Name: emergency_contacts; Type: TABLE; Schema: public; Owner: pawsco_user
--

CREATE TABLE public.emergency_contacts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(100) NOT NULL,
    relationship character varying(50),
    phone character varying(20) NOT NULL,
    email character varying(255),
    is_primary boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.emergency_contacts OWNER TO pawsco_user;

--
-- Name: emergency_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: pawsco_user
--

CREATE SEQUENCE public.emergency_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.emergency_contacts_id_seq OWNER TO pawsco_user;

--
-- Name: emergency_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawsco_user
--

ALTER SEQUENCE public.emergency_contacts_id_seq OWNED BY public.emergency_contacts.id;


--
-- Name: health_records; Type: TABLE; Schema: public; Owner: pawsco_user
--

CREATE TABLE public.health_records (
    id integer NOT NULL,
    pet_id integer NOT NULL,
    vet_name character varying(100),
    vet_phone character varying(20),
    vet_clinic character varying(100),
    allergies text,
    medications text,
    medical_conditions text,
    special_care_instructions text,
    last_checkup_date date,
    next_checkup_date date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.health_records OWNER TO pawsco_user;

--
-- Name: health_records_id_seq; Type: SEQUENCE; Schema: public; Owner: pawsco_user
--

CREATE SEQUENCE public.health_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.health_records_id_seq OWNER TO pawsco_user;

--
-- Name: health_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawsco_user
--

ALTER SEQUENCE public.health_records_id_seq OWNED BY public.health_records.id;


--
-- Name: pets; Type: TABLE; Schema: public; Owner: pawsco_user
--

CREATE TABLE public.pets (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(100) NOT NULL,
    species character varying(50),
    breed character varying(100),
    age numeric(4,2),
    weight numeric(6,2),
    vaccinated boolean DEFAULT false,
    is_primary boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.pets OWNER TO pawsco_user;

--
-- Name: pets_id_seq; Type: SEQUENCE; Schema: public; Owner: pawsco_user
--

CREATE SEQUENCE public.pets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pets_id_seq OWNER TO pawsco_user;

--
-- Name: pets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawsco_user
--

ALTER SEQUENCE public.pets_id_seq OWNED BY public.pets.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: pawsco_user
--

CREATE TABLE public.services (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    base_price numeric(10,2) NOT NULL,
    duration_minutes integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.services OWNER TO pawsco_user;

--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: pawsco_user
--

CREATE SEQUENCE public.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.services_id_seq OWNER TO pawsco_user;

--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawsco_user
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: pawsco_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    phone character varying(20),
    street_address character varying(255),
    city character varying(100),
    state character varying(2),
    zip_code character varying(10),
    role character varying(50) DEFAULT 'user'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO pawsco_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: pawsco_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO pawsco_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pawsco_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: booking_addons id; Type: DEFAULT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.booking_addons ALTER COLUMN id SET DEFAULT nextval('public.booking_addons_id_seq'::regclass);


--
-- Name: bookings id; Type: DEFAULT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.bookings ALTER COLUMN id SET DEFAULT nextval('public.bookings_id_seq'::regclass);


--
-- Name: emergency_contacts id; Type: DEFAULT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.emergency_contacts ALTER COLUMN id SET DEFAULT nextval('public.emergency_contacts_id_seq'::regclass);


--
-- Name: health_records id; Type: DEFAULT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.health_records ALTER COLUMN id SET DEFAULT nextval('public.health_records_id_seq'::regclass);


--
-- Name: pets id; Type: DEFAULT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.pets ALTER COLUMN id SET DEFAULT nextval('public.pets_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: booking_addons; Type: TABLE DATA; Schema: public; Owner: pawsco_user
--

COPY public.booking_addons (id, booking_id, addon_id, price_at_purchase, created_at) FROM stdin;
\.
COPY public.booking_addons (id, booking_id, addon_id, price_at_purchase, created_at) FROM '$$PATH$$/3494.dat';

--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: pawsco_user
--

COPY public.bookings (id, user_id, pet_id, service_id, booking_date, booking_time, special_notes, subtotal, tax, total, status, created_at, updated_at) FROM stdin;
\.
COPY public.bookings (id, user_id, pet_id, service_id, booking_date, booking_time, special_notes, subtotal, tax, total, status, created_at, updated_at) FROM '$$PATH$$/3492.dat';

--
-- Data for Name: emergency_contacts; Type: TABLE DATA; Schema: public; Owner: pawsco_user
--

COPY public.emergency_contacts (id, user_id, name, relationship, phone, email, is_primary, created_at) FROM stdin;
\.
COPY public.emergency_contacts (id, user_id, name, relationship, phone, email, is_primary, created_at) FROM '$$PATH$$/3496.dat';

--
-- Data for Name: health_records; Type: TABLE DATA; Schema: public; Owner: pawsco_user
--

COPY public.health_records (id, pet_id, vet_name, vet_phone, vet_clinic, allergies, medications, medical_conditions, special_care_instructions, last_checkup_date, next_checkup_date, created_at, updated_at) FROM stdin;
\.
COPY public.health_records (id, pet_id, vet_name, vet_phone, vet_clinic, allergies, medications, medical_conditions, special_care_instructions, last_checkup_date, next_checkup_date, created_at, updated_at) FROM '$$PATH$$/3498.dat';

--
-- Data for Name: pets; Type: TABLE DATA; Schema: public; Owner: pawsco_user
--

COPY public.pets (id, user_id, name, species, breed, age, weight, vaccinated, is_primary, created_at) FROM stdin;
\.
COPY public.pets (id, user_id, name, species, breed, age, weight, vaccinated, is_primary, created_at) FROM '$$PATH$$/3488.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: pawsco_user
--

COPY public.services (id, name, description, base_price, duration_minutes, created_at) FROM stdin;
\.
COPY public.services (id, name, description, base_price, duration_minutes, created_at) FROM '$$PATH$$/3490.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: pawsco_user
--

COPY public.users (id, email, password_hash, first_name, last_name, phone, street_address, city, state, zip_code, role, created_at, updated_at) FROM stdin;
\.
COPY public.users (id, email, password_hash, first_name, last_name, phone, street_address, city, state, zip_code, role, created_at, updated_at) FROM '$$PATH$$/3486.dat';

--
-- Name: booking_addons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawsco_user
--

SELECT pg_catalog.setval('public.booking_addons_id_seq', 1, false);


--
-- Name: bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawsco_user
--

SELECT pg_catalog.setval('public.bookings_id_seq', 1, true);


--
-- Name: emergency_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawsco_user
--

SELECT pg_catalog.setval('public.emergency_contacts_id_seq', 2, true);


--
-- Name: health_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawsco_user
--

SELECT pg_catalog.setval('public.health_records_id_seq', 1, false);


--
-- Name: pets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawsco_user
--

SELECT pg_catalog.setval('public.pets_id_seq', 3, true);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawsco_user
--

SELECT pg_catalog.setval('public.services_id_seq', 6, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pawsco_user
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: booking_addons booking_addons_pkey; Type: CONSTRAINT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.booking_addons
    ADD CONSTRAINT booking_addons_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: emergency_contacts emergency_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.emergency_contacts
    ADD CONSTRAINT emergency_contacts_pkey PRIMARY KEY (id);


--
-- Name: health_records health_records_pkey; Type: CONSTRAINT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.health_records
    ADD CONSTRAINT health_records_pkey PRIMARY KEY (id);


--
-- Name: pets pets_pkey; Type: CONSTRAINT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.pets
    ADD CONSTRAINT pets_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_bookings_date; Type: INDEX; Schema: public; Owner: pawsco_user
--

CREATE INDEX idx_bookings_date ON public.bookings USING btree (booking_date);


--
-- Name: idx_bookings_pet_id; Type: INDEX; Schema: public; Owner: pawsco_user
--

CREATE INDEX idx_bookings_pet_id ON public.bookings USING btree (pet_id);


--
-- Name: idx_bookings_user_id; Type: INDEX; Schema: public; Owner: pawsco_user
--

CREATE INDEX idx_bookings_user_id ON public.bookings USING btree (user_id);


--
-- Name: idx_emergency_contacts_user_id; Type: INDEX; Schema: public; Owner: pawsco_user
--

CREATE INDEX idx_emergency_contacts_user_id ON public.emergency_contacts USING btree (user_id);


--
-- Name: idx_health_records_pet_id; Type: INDEX; Schema: public; Owner: pawsco_user
--

CREATE INDEX idx_health_records_pet_id ON public.health_records USING btree (pet_id);


--
-- Name: idx_pets_user_id; Type: INDEX; Schema: public; Owner: pawsco_user
--

CREATE INDEX idx_pets_user_id ON public.pets USING btree (user_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: pawsco_user
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: pawsco_user
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: booking_addons booking_addons_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.booking_addons
    ADD CONSTRAINT booking_addons_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON DELETE CASCADE;


--
-- Name: bookings bookings_pet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pet_id_fkey FOREIGN KEY (pet_id) REFERENCES public.pets(id) ON DELETE CASCADE;


--
-- Name: bookings bookings_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: bookings bookings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: emergency_contacts emergency_contacts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.emergency_contacts
    ADD CONSTRAINT emergency_contacts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_records health_records_pet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.health_records
    ADD CONSTRAINT health_records_pet_id_fkey FOREIGN KEY (pet_id) REFERENCES public.pets(id) ON DELETE CASCADE;


--
-- Name: pets pets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pawsco_user
--

ALTER TABLE ONLY public.pets
    ADD CONSTRAINT pets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

